
export default function Home() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Workout App (placeholder)</h1>
      <p>Deze versie toont nog geen functionaliteit, maar is klaar voor installatie als PWA.</p>
    </div>
  );
}
